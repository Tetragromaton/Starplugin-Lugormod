#pragma once
#include "jka/game/g_local.h"
#include "jka/game/q_shared.h"

gentity_t* SP_Beam(gentity_t* ent);
gentity_t* SP_Fire(gentity_t* ent);
void InitBuildables();