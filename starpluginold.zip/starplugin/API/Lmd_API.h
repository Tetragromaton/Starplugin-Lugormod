
#ifndef LMD_API_H
#define LMD_API_H

#ifndef LUGORMOD

typedef const void *(*LmdApi_Get_f)(unsigned int version);

#endif

#endif