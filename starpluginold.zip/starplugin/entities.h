#pragma once

#define NUM_PENTS 1

void InitEntities();